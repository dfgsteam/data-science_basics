from find_single import find_single_element

if __name__ == "__main__":
    example_input = [1, 2, 3, 4, 3, 1, 2]
    result = find_single_element(example_input)
    print(f"The single element in the array {example_input} is {result}")
